$(function(){
  var l = new Login();
})


class Login {
  constructor() {
    this.submitEvent()
  }

  submitEvent(){
    $('form').submit((event)=>{
      event.preventDefault()
      this.sendForm()
    })
  }

  sendForm(){
    let form_data = new FormData();
    form_data.append('username', $('#user').val());
    form_data.append('password', $('#password').val());
    $.ajax({
      url: '../server/check_login.php',
      type: 'POST',
      dataType: 'JSON',
      cache: false,
      processData: false,
      contentType: false,
      data: form_data,
      success: function(php_response){
        php_response.forEach(function(element){
          console.log(element.msg);
          if (element.msg == "OK") {
            window.location.href = 'main.html';
            sessionStorage.setItem('id_Usuarios',element.id_Usuarios);
            var objetoApp = new EventsManager();
            objetoApp.pruebaComunicaciónFunciones();
          }else {
            alert(element.msg);
          }
        })
      },
      error: function(jXHRTypeError, errorMessage){
        console.log("Mensaje de error: " + errorMessage);
        console.log("Tipo de error: " +  jXHRTypeError.status);
      },

    })
  }
}

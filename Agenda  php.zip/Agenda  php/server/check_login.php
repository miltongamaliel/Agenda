<?php
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('content-type: application/json; charset=utf-8');
  require_once "dbConection.php";
  $username = $_POST['username'];
  $password = $_POST['password'];

/* Esta línea es para validar la correcta comunicación con cliente. Regresa los mismos
   datos recibidos y cliente con un forEach lee el dato y los presenta en consola.

   $responseArray[] = array('usuario'=>$username,'contrasena'=>$password);
   $responseJson = json_encode($responseArray);
   echo $responseJson;
*/

  $responseArray = conectar::validarUsuarioEnTabla($username, $password);
  echo $responseArray;
?>

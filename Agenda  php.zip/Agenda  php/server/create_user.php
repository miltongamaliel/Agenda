<?php
  require_once "dbConection.php";

  class crearUsuarios {
    public function insertarUsuario(){
      $usuarios = array(
        array("usuario"=>"milton@hotmail.com",
          "nombre_completo"=>"Milton Gamaliel",
          "Contrasena"=>"00001", // La contraseña será guardada en la BD con criptografía. se usará la función password_hash() en
          //la función insertar línea del archivo dbConection.
          "fecha_nacimiento"=>"2000/01/01"),
        array("usuario"=>"andrea@hotmail.com",
          "nombre_completo"=>"Andrea Barcenas",
          "Contrasena"=>"00002",
          "fecha_nacimiento"=>"1990/07/13"),
        array("usuario"=>"melanny@hotmail.com",
          "nombre_completo"=>"Melanny Zuniga",
          "Contrasena"=>"00003",
          "fecha_nacimiento"=>"2000/11/27"));

          foreach($usuarios as $key=>$value){
            echo "El arreglo que se enviara a metodo insertarLinea es: <br>";
            print_r ($value);
            $conexion=conectar::insertarLinea("usuarios",$value);
          }
    }
  }
  crearUsuarios::insertarUsuario();
  //conectar::vaciarTabla();
 ?>

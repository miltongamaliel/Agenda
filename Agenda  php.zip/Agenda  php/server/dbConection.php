<?php
class conectar{
  public function conexion(){
    $host = 'localhost';
    $user = 'UserRoot';
    $password = 'Welcome00001';
    $dbName = 'calendario';
    $conexion;
    $conexion = new mysqli($host, $user, $password, $dbName);
    if($conexion->connect_error){
      return "Error: ".$conexion->connect_error;
    }else {

    }
    return $conexion;
  }

  public function insertarLinea ($tablaNombre,$datos){
  //  Llama la función conexión, esta abre una conexión entre el server & el server de BD
  //mysqli. La función usa el método mysqli para la conexion.
    $conexion1 = conectar::conexion();
    $db = 'INSERT INTO '. $tablaNombre .' (';
    $i=1;

    foreach($datos as $key=>$value){
      $db .= $key;
      if($i<count($datos)){
        $db .= ",";
      }else {
        $db .= ")";
      }
      $i++;
    }
    $db .= " VALUES ( ";
    $i = 1;
    foreach($datos as $key=>$value){
      if($key=="Contrasena"){
        $db .= "'". password_hash($value,PASSWORD_DEFAULT) ."'";
      }else{
        $db .= "'". $value ."'";
      }
      if($i<count($datos)){
        $db .= ",";
      }else {
        $db .= ")";
      }
    $i++;
    }
  echo "la sentencia sql enviada es: " . $db;
    if (mysqli_query($conexion1, $db)) {
//     echo "<br> New record created successfully". "<br>  -------  <br>";
    } else {
//     echo "Error: " . $db . "<br>" . mysqli_error($conexion1);
    }

    mysqli_close($conexion1);
  }

  public function consultarTabla($tablaNombre){
    $conexion1 = conectar::conexion();
    //Sentencia realiza una colsulta de TODOS los datos de la tabla "tablaNombre".
    $db ='SELECT * FROM '  . $tablaNombre;


    if ($query=mysqli_query($conexion1, $db)) {
      $eventos [] = array ('msg'=>'OK');
      while($queryPerRow = mysqli_fetch_assoc($query)){

        $eventos[] = array(
            'title' => $queryPerRow['titulo'],
            'start' => $queryPerRow['fecha_Inicio'],
            'allDay' => $queryPerRow['dia_Completo'],
            'end' => $queryPerRow['fecha_Finalizacion'],
            'endTime' => $queryPerRow['hora_Finalizacion'],
            'startTime' => $queryPerRow['hora_Inicio'],
            'id' => $queryPerRow['id']
         );
      }
    } else {
      $eventos[0]['msg']  =  "Error: " . mysqli_error($conexion1);
    }
    $responseJson  = json_encode( $eventos );
    return $responseJson;
    mysql_free_result($query); // Limpieza de memoria referente a este recurso.
    mysqli_close($conexion1);
  }

  public function validarUsuarioEnTabla($username, $password){
    $conexion1 = conectar::conexion();
    $db = 'SELECT * FROM usuarios';
    if ($query=mysqli_query($conexion1, $db)) {
      $queryPerRow = mysqli_fetch_assoc($query);

     if (password_verify($password,$queryPerRow['contrasena'])) {
        $responseArray [] = array('msg'=>'OK', 'id_Usuarios'=>$queryPerRow['id']);
      }else {
        $responseArray [] = array('msg'=>'Contrasena equivocada ');
      }
    } else {
      $responseArray []= array('msg'=> "MySql - Error: " . $db . "<br>" . mysqli_error($conexion1));
    }
    $responseJson = json_encode($responseArray);
    mysqli_free_result($query); // Limpieza de memoria referente a este recurso.
    mysqli_close($conexion1);
    return $responseJson;
  }



  public function eliminarEvento($eventoId){
    $conexion1 = conectar::conexion();
    $db = 'DELETE  FROM eventos WHERE eventos.id=' .  $eventoId;
    if ($query=mysqli_query($conexion1, $db)){
      $responseArray [] = array('msg'=>'OK');
    }else{
      $responseArray [] = array('msg'=> "MySql - Error: " . $db . "<br>" . mysqli_error($conexion1));
    }
    $responseJson = json_encode($responseArray);
    mysqli_free_result($query); // Limpieza de memoria referente a este recurso.
    mysqli_close($conexion1);
    return $responseJson;
  }


  public function vaciarTabla(){
    $conexion1 = conectar::conexion();
    $db = "DELETE FROM usuarios";
    if (mysqli_query($conexion1, $db)) {
    //  echo "Delete table content successfully";
    } else {
    //  echo "Error: " . $db . "<br>" . mysqli_error($conexion1);
    }
    mysqli_close($conexion1);
  }
}
?>

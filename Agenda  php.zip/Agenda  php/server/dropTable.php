<?php
require_once "dbConection.php";
conectar::vaciarTabla();

 ?>

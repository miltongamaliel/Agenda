<?php
  require_once "dbConection.php";
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('content-type: application/json; charset=utf-8');



  if(isset($_POST['titulo'])){
    $formdataTitulo = $_POST['titulo'];
//    echo "<br> Titulo: " . $formdataTitulo;
  }

  if(isset($_POST['start_date'])){
    $formdataStartDate = $_POST['start_date'];
//    echo "<br> Start_Date: " . $formdataStartDate;
  }

  if(isset($_POST['allDay'])){
    $formdataAllDay = $_POST['allDay'];
    if($formdataAllDay == 'true'){
      $formdataAllDay = 1;
    }else{
      $formdataAllDay = 0;
    }
//    echo "<br> all_Day: " . $formdataAllDay;
  }

  if(isset($_POST['end_date'])){
    $formdataEndDate = $_POST['end_date'];
//    echo "<br> end_Date: " . $formdataEndDate;
  }

  if(isset($_POST['end_hour'])){
    $formdataEndHour = $_POST['end_hour'];
//    echo "<br> end_hour: " . $formdataEndHour;
  }
  if(isset($_POST['start_hour'])){
    $formdataStartHour = $_POST['start_hour'];
//    echo "<br> Start_Hour: " . $formdataStartHour;
  }
  if(isset($_POST['id_Usuarios'])){
    $formdataId_Usuarios = $_POST['id_Usuarios'];
    echo "<br> Start_Hour: " . $formdataId_Usuarios;
  }


// Si se colocan [] después del nombre para definir el array, genera parseError.
   $responseArray = array(
      'titulo'=> $formdataTitulo,
      'fecha_Inicio'=>$formdataStartDate,
      'dia_Completo'=>$formdataAllDay,
      'fecha_Finalizacion'=>$formdataEndDate,
      'hora_Finalizacion'=>$formdataEndHour,
      'hora_Inicio'=>$formdataStartHour,
      'FK_Usuario'=>$formdataId_Usuarios,
    );


/* La siguiente línea manda un array como retorno a js, gener error de interpretación, enchant_broker_describe
ser convertiro a Json
  echo $responseArray;
*/


/* Las siguientes dos líneas convierten un array a json y luego lo retorna para comprobar buena recepcion.
funcionan correctamente.
  $jsonEncode = json_encode($responseArray);
  echo $jsonEncode;
*/



  $jsonEncode = json_encode($responseArray);
  conectar::insertarLinea('eventos', $responseArray);

 ?>

var http = require("http"),
  mongoClient = require('mongodb').MongoClient,
  assert = require('assert'),
  router = require('router'),
  express = require('express'),
  bodyParser = require('body-parser'),
  cors = require('cors'),
  functions = require('./functions.js');

var app = express ();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));
app.use(cors());

var PORT = 8080;

app.post('/login',function(req, res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With,       Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');
  functions.login(req,res);
});

app.post('/events/all',function(req,res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With,       Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');
  functions.getEvents(req,res);
});

app.post('/events/new', function(req,res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With,       Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');
  functions.newEvent(req, res);
});

app.post('/events/delete', function(req,res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With,       Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');
  functions.deleteEvent(req,res);
});

//Server listener, port configuration by PORT variable.
  app.listen(PORT, function(){
    console.log('Server is listening on port: ' + PORT);
  });


var mongoClient = require('mongodb').MongoClient,
  assert = require('assert');
// Connection URL+ database_name
var url = 'mongodb://localhost:27017',
  dbName = 'calendario';

var client = new mongoClient(url, {useNewParser:true});
client.connect(function(){
  var db = client.db(dbName);
  var collectionDb = db.collection('miltongamaliel');
  collectionDb.insertMany([
    {"dataUser":
      {email: 'milton@hotmail.com',
      name:'Milton G. Lopez',
      password:'00001',
      birth_date:'01/01/2002'}
    }
  ]);
});

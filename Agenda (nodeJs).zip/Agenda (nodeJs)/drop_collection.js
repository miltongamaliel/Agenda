var http = require('http'),
  bodyParser = require('body-parser'),
  express = require('express'),
  fs = require('fs'),
  path = require('path'),
  mongoClient = require('mongodb').MongoClient,
  cors = require('cors');
var PORT = 8080;

var url = 'mongodb://localhost:27017',
  dbName = 'calendario';

var client = new mongoClient(url, {useNewParser:true});
var server  = http.createServer(),
app = express(server);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));
app.use(cors());
var fileJSON = 'data.json';


app.post('/',function(req, res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');

  client.connect(function(){
    var db = client.db(dbName);
    db.dropCollection('miltongamaliel',function(e,result){
      if(e){
        console.log("Al intentar borrar la coleccion se ha presentado el error: ", e);
      }else{
        console.log("Collection removed successfully");
      }
    });
  });
});

app.listen(PORT, function(){
  console.log('Server is listening on port: ' + PORT);

  client.connect(function(){
    var db = client.db(dbName);
    db.dropCollection('miltongamaliel',function(e,result){
      if(e){
        console.log("Al intentar borrar la coleccion se ha presentado el error: ", e);
      }else{
        console.log("Collection removed successfully");
      }
    });
  });
});

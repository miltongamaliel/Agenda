var http = require('http'),
  express = require('express'),
  session = require('express-session'),
  fs = require('fs'),
  path = require('path'),
  mongoClient = require('mongodb').MongoClient;

var url = 'mongodb://localhost:27017',
  dbName = 'calendario',
  client = new mongoClient(url, {useNewParser:true});

var functions = {
  headerResponse:function(req, res){
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With,       Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Content-Type', 'application/json');
    console.log("Header response, OK");
  },

  login:function (req, res){
    client.connect(function(){
      var db = client.db(dbName),
        userValidated = req.body['user'];
        collectionDb = db.collection(userValidated);
        var userPassword = collectionDb.find({}).toArray(function(err,data){
          var userPass = data[0]['dataUser']['password'];
          if(req.body['pass']==userPass){
            console.log("las contraseñas han concordado");
            res.send({"response":"Validado"});
          }
          db.close;
        });
    });
  },

  newEvent: function(req, res){
    client.connect(function(){
      var db = client.db(dbName);
      var ev = req.body;
      var  collectionDb = db.collection(ev['userValidated']);

      collectionDb.insertOne(ev,function(err,result){
        if(result){
            console.log("Saved data successfuly");
        }else{
            console.log("El error arrojado es: ", err.message);
        }
      });

      db.close;
    });
  },

  getEvents: function(req,res){
      client.connect(function(){
        var db = client.db(dbName),
          userValidated = req.body['userValidated'],
        collectionDb = db.collection(userValidated);
        var event = collectionDb.find().toArray(function(err,data){
          var events = data.shift();
          res.send(data);
          db.close;
        });
      });
  },

  deleteEvent: function (req, res){
    client.connect(function(){
      var db = client.db(dbName),
        userValidated = req.body['userValidated'],
        idElement = req.body['id'],
      collectionDb = db.collection(userValidated);
      console.log("Desde deleteEvent, el id es: ", idElement, "el usuario es: ", userValidated );
      var docBuscado = collectionDb.find({"title":idElement}).toArray(function(err,data){
        console.log("En deleteEvent, error es: ", data);
      });
/*      collectionDb.deleteOne({'_id':req.body['id']},function(err,result){
        if(result){
            console.log("Delete data successfuly");
            res.send(result);
        }else{
            console.log("Al borrar un docuemtno, el error arrojado es: ", err.message);
        }
      });
*/
  db.close;
});
 }


}

module.exports = functions;

var http = require('http'),
  bodyParser = require('body-parser'),
  express = require('express'),
  fs = require('fs'),
  path = require('path'),
  mongoClient = require('mongodb').MongoClient,
  cors = require('cors');

var url = 'mongodb://localhost:27017',
  dbName = 'calendario',
  PORT = 8080;

var client = new mongoClient(url, {useNewParser:true});
var server  = http.createServer(),
  app = express(server);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));
app.use(cors());



app.post('/',function(req, res){
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Content-Type', 'application/json');
  client.connect(function(){
    var db = client.db(dbName);
    var collectionDb = db.collection(req.body['user']);
    var userPassword = collectionDb.find({}).toArray(function(err,data){
    var userPass = data[2]['password'];
    if(req.body['pass']==userPass){
      console.log("las contraseñas han concordado");
      res.send({"response":"Validado"});
    }
      db.close;
    });
  });
});

app.listen(PORT, function(){
  console.log('Server is listening on port: ' + PORT);
});
